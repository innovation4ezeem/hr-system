import { redirect } from 'next/navigation';

export default function ManagerDashboardPage() {
  redirect('/manager-dashboard/overview');
}